package PageFactoryElements;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class loginPage {
	
	public loginPage(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//*[@id=\"essenceCartBtn\"]")
	WebElement addtocart;
	

	@FindBy(xpath="/html/body/div[2]/div[2]/div[2]/div/a")
	WebElement checkout;
	
	@FindBy(xpath="//*[@id=\"first_name\"]")
	WebElement firstname;
	
	@FindBy(xpath="//*[@id=\"last_name\"]")
	WebElement lastname;
	
	@FindBy(xpath="//*[@id=\"company\"]")
	WebElement companyname;
	
	@FindBy(xpath="/html/body/div[4]/div/div/div[1]/div/form/div/div[4]/div")
	WebElement dropdown;
	
	@FindBy(xpath="/html/body/div[4]/div/div/div[1]/div/form/div/div[4]/div/ul/li[5]")
	WebElement selectoption;
	
	@FindBy(xpath="//*[@id=\"street_address\"]")
	WebElement enteraddress;
	
	@FindBy(xpath="//*[@id=\"postcode\"]")
	WebElement enterpostcode;
	
	@FindBy(xpath="//*[@id=\"city\"]")
	WebElement entercity;
	
	@FindBy(xpath="//*[@id=\"state\"]")
	WebElement enterstate;
	
	@FindBy(xpath="//*[@id=\"phone_number\"]")
	WebElement enterphonenum;
	
	@FindBy(xpath="//*[@id=\"email_address\"]")
	WebElement enteremail;
	
	@FindBy(xpath="/html/body/div[4]/div/div/div[1]/div/form/div/div[11]/div[1]/label")
	WebElement clickoncheckbox;
	
	@FindBy(xpath="/html/body/div[4]/div/div/div[2]/div/a")
	WebElement clickonplaceorder;
	
	public void addcart() 
	{
		addtocart.click();
		
	}
	
	public void checkoutopt()
	{
		checkout.click();
	}
	
	public void first()
	{
		firstname.sendKeys("Vihana");
	}
	
	public void last()
	{
		lastname.sendKeys("Palla");
		
	}
	
	public void company()
	{
		companyname.sendKeys("Wipro");
		
	}
	public void drop()
	{
		dropdown.click();
		
	}
	public void select()
	{
		selectoption.click();
		
	}
	public void address()
	{
		enteraddress.sendKeys("Electronic city");
		
	}
	public void code()
	{
		enterpostcode.sendKeys("560100");
		
	}
	public void city()
	{
		entercity.sendKeys("Bangalore");
		
	}
	public void state()
	{
		enterstate.sendKeys("Karnataka");
		
	}
	public void phone()
	{
		enterphonenum.sendKeys("987654321");
		
	}
	public void email()
	{
		enteremail.sendKeys("xyz@gmail.com");
		
	}
	public void checkbox()
	{
		clickoncheckbox.click();
		
	}
	public void placeorder()
	{
		clickonplaceorder.click();
		
	}
	

}
