package Utilities;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class DriverInialization {
	
	
	public static WebDriver getDriver()
	{
		ChromeOptions opt=new ChromeOptions();
		opt.addArguments("--remote-allow-origins=*");
		WebDriver driver=new ChromeDriver(opt);
		driver.get("http://localhost:8080/ATE_PEP2_Testing_Using_TestNG/");
		return driver;
		
		
	}

}
