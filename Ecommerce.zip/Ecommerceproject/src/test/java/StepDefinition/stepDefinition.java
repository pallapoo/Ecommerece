package StepDefinition;

import PageFactoryElements.loginPage;
import Utilities.DriverInialization;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class stepDefinition {
	
	loginPage obj= new loginPage(DriverInialization.getDriver());
	
	@Given("User launch the Ecommerce application")
	public void user_launch_the_ecommerce_application() {
		
		
		System.out.println("Browser launched and working fine");
	    
	}
	
	@Then("User click on add to cart option")
	public void user_click_on_add_to_cart_option() throws InterruptedException {
	    
		System.out.println("User clicks on add to cart option for product confirmation");
		obj.addcart();
		
		Thread.sleep(2000);
		
	}
	
	@Then("user clicks on checkout options for products")
	public void user_clicks_on_checkout_options_for_products() {
	    obj.checkoutopt();
	}
	
	@Then("user enters first name")
	public void user_enters_first_name() {
	    obj.first();
	}
	
	@Then("User enters last name")
	public void user_enters_last_name() {
	    obj.last();
	}

	@Then("user enters company name")
	public void user_enters_company_name() {
	    obj.company();
	}
	
	@When("user clicks on dropdown")
	public void user_clicks_on_dropdown() {
	    obj.drop();
	}
	@When("Selects on India")
	public void selects_on_india() {
	    obj.select();
	}
	
	@Then("User Enters address")
	public void user_enters_address() {
	   obj.address();
	}

	@Then("User enter post code")
	public void user_enter_post_code() {
	    obj.code();
	}

	@Then("user enters town name")
	public void user_enters_town_name() {
	    obj.city();
	}

	@Then("user enters province name")
	public void user_enters_province_name() {
	    obj.state();
	}

	@Then("user enters phone number")
	public void user_enters_phone_number() {
	   obj.phone();
	}

	@Then("user enters address line")
	public void user_enters_address_line() {
	    obj.email();
	}
	@Then("user checks checkbox")
	public void user_checks_checkbox() {
	    obj.checkbox();
	}

	@Then("click on placeorder button")
	public void click_on_placeorder_button() {
	    obj.placeorder();
	}



}
