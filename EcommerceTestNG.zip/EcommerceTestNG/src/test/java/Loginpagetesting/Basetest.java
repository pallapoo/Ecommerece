package Loginpagetesting;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;


public class Basetest {
	
	protected ChromeDriver driver;
	
	@Test 
	public void OpenBrowser() throws InterruptedException
	{
	WebDriverManager.chromedriver().setup();
	driver = new ChromeDriver();
	
	driver.manage().window().maximize();
	Thread.sleep(2000);
	driver.get("http://localhost:8080/ATE_PEP2_Testing_Using_TestNG/");
	}
	public ChromeDriver getDriver() {
		return driver;
	}

}
