package Loginpagetesting;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class Homepage extends Basetest{
	
	public void homepagetest() throws InterruptedException
	{
		
		Basetest obj1=new Basetest();
		obj1.OpenBrowser();
		
		WebElement ele = driver.findElement(By.xpath("//a[text()='Pages']"));
		
		Actions action=new Actions(driver);
		Thread.sleep(2000);
		action.moveToElement(ele).build().perform();
		
		WebElement ele1 = driver.findElement(By.xpath("//a[text()='Contact']"));
		ele1.click();		
		Thread.sleep(2000);
		       
        Alert alert = driver.switchTo().alert();		    
        String alertMessage= driver.switchTo().alert().getText();
        Thread.sleep(5000);

		System.out.println(alertMessage);
		alert.accept();
		
	}
}
