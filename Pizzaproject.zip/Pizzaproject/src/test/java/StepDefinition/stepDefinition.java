package StepDefinition;

import Utilities.DriverInialization;
import PageFactoryElements.loginPage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class stepDefinition {
	
	loginPage obj= new loginPage(DriverInialization.getDriver());
	
	
	@Given("userenters the pizzahut application url")
	public void userenters_the_pizzahut_application_url() {
		System.out.println("Browser launched and working fine");
	}
	
	@Then("User type address as {string}")
	public void user_type_address_as(String Location) throws InterruptedException {
		
			obj.pizzaapplication(Location);

	}
	
	@Then("User validate vegetarian radio button flag is off")
	public void user_validate_vegetarian_radio_button_flag_is_off() throws InterruptedException {
		
	    obj.vegetarianbutton();
	}

	@Then("User clicks on Pizzas menu bar option")
	public void user_clicks_on_pizzas_menu_bar_option() {
		obj.pizzaoption();
	   
	}
	
	@When("User select add button of any pizza from Recommended")
	public void user_select_add_button_of_any_pizza_from_recommended() throws InterruptedException {
	    obj.addpizza();
	}
	
	@Then("User see that the pizza is getting added under Your Basket")
	public void user_see_that_the_pizza_is_getting_added_under_your_basket() throws InterruptedException {
	
		obj.pizzaname();
		   
	}
	
	@Then("User validate checkout button contains Item count")
	public void user_validate_checkout_button_contains_item_count() throws InterruptedException {
		
		obj.basket();
	    
	}

	@Then("User validate checkout button contains total price count")
	public void user_validate_checkout_button_contains_total_price_count() {
	    
		obj.amount();
	}
	
	@Then("User clicks on Drinks option")
	public void user_clicks_on_drinks_option() {
	    
		obj.drinks();
	}

	@Then("User select Pepsi option to add into the Basket")
	public void user_select_pepsi_option_to_add_into_the_basket() throws InterruptedException {
	    
		obj.pepsi();
	}

	@Then("User see {int} items are showing under checkout button")
	public void user_see_items_are_showing_under_checkout_button(Integer int1) throws InterruptedException {
	   
		obj.count();
	}
	@Then("User see total price is now more than before")
	public void user_see_total_price_is_now_more_than_before() {
	    obj.after();
	}

	@Then("User remove the Pizza item from Basket")
	public void user_remove_the_pizza_item_from_basket() {
	    obj.remove();
	}


	@Then("User see {int} item showing in checkout button")
	public void user_see_item_showing_in_checkout_button(Integer int1) throws InterruptedException {
	   obj.cremove();
	}

	@Then("User Clicks on Checkout button")
	public void user_clicks_on_checkout_button() {
	   obj.finalcheckout();
	}

	@Then("User see minimum order required pop up is getting displayed")
	public void user_see_minimum_order_required_pop_up_is_getting_displayed() {
	    obj.minimum();
	}
}
	
	

