package StepDefinition;

import org.junit.runner.RunWith;

import io.cucumber.junit.*;

@RunWith(Cucumber.class)
@CucumberOptions
( features="src/test/java/AppFeatures",
glue= {"StepDefinition"}



		
		)
public class TestRunner {

}
