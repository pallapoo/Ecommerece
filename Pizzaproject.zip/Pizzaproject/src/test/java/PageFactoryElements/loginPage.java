package PageFactoryElements;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Assert;
import org.openqa.selenium.Keys;
//import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
//import org.openqa.selenium.interactions.Actions;

public class loginPage {
	
	
	public loginPage(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//input[@type=\"text\"]")
	WebElement locationbar1;
		
	@FindBy(css="#app > div > div.order > div.basket-placeholder > div.flex.lg\\:flex-col > div.side-menu.lg\\:shadow-down-1.lg\\:border-b.lg\\:border-t > div > div > div > span.py-4.px-5.border.rounded-full.flex.items-center.cursor-pointer.bg-grey-light.border-grey-light.justify-start")
	WebElement radio;
	
	@FindBy(xpath="//*[@id=\"app\"]/div/div[1]/div[1]/div[3]/div[1]/div/a[2]/span")
	WebElement pizza;
	
	@FindBy(xpath="//*[@id=\"app\"]/div/div[1]/div[1]/div[3]/div[2]/div[2]/span/div[1]/a[1]/div[3]/div/button")
	WebElement pizza1;
	
//	WebElement yourBasket = driver.findElement(By.xpath("//div[@class='basket-list']"));
//    assertTrue(yourBasket.isDisplayed());
	
	@FindBy(xpath="//*[@id=\"basket\"]/div[3]/div/div[1]/div[1]")
	WebElement itemname;
    
    
    @FindBy(xpath="//*[@id=\"app\"]/div/div[1]/div[2]/div/div[2]/div[3]/div/div/div/a/span[1]/span")
    WebElement yourBasket;
    @FindBy(xpath="//*[@id=\"app\"]/div/div[1]/div[2]/div/div[2]/div[3]/div/div/div/a/span[3]/span")
    WebElement checkoutamount;
    
    @FindBy(xpath="//*[@id=\"app\"]/div/div[1]/div[1]/div[3]/div[1]/div/a[5]")
    WebElement adddrinks;
    
    @FindBy(xpath="//*[@id=\"app\"]/div/div[1]/div[1]/div[3]/div[2]/div[2]/span/div/a[1]/div[3]/div/button/span[1]/span")
    WebElement addpepsi;
    
    @FindBy(xpath="//*[@id=\"app\"]/div/div[1]/div[2]/div/div[2]/div[3]/div/div/div/a/span[1]/span")
    WebElement Basketcount;
    
    @FindBy(xpath="//*[@id=\"app\"]/div/div[1]/div[2]/div/div[2]/div[3]/div/div/div/a/span[3]/span")
    WebElement afteramount;
    
    @FindBy(xpath="//*[@id=\"basket\"]/div[3]/div/div[1]/button[2]")
    WebElement removepizza;
    
    @FindBy(xpath="//*[@id=\"app\"]/div/div[1]/div[2]/div/div[2]/div[3]/div[2]/div/div/button/span[1]/span")
    WebElement removecount;
    
    @FindBy(xpath="//*[@id=\"app\"]/div/div[1]/div[2]/div/div[2]/div[3]/div[2]/div/div/button/span[2]/span")
    WebElement fcheckout;
    
    @FindBy(xpath="/html/body/div[6]/div/div/div/h3/span")
    WebElement minimumorder;
    
    
    
   
	
	public void pizzaapplication(String text3) throws InterruptedException
	{
		locationbar1.sendKeys(text3);
		Thread.sleep(2000);
		locationbar1.sendKeys(Keys.ENTER);
		Thread.sleep(2000);
		
	}
	
	public void vegetarianbutton() throws InterruptedException
	{
		Thread.sleep(5000);
		radio.click();
	}
	
	public void pizzaoption()
	{
		pizza.click();
	}
	
	public void addpizza() throws InterruptedException
	{
		Thread.sleep(2000);
		pizza1.click();
	}
	
	public void pizzaname() throws InterruptedException
	{
		Thread.sleep(2000);
		assertEquals(itemname.getText(), "Medium Schezwan Margherita");
	}
	
	public void basket() throws InterruptedException
	{
		Thread.sleep(2000);
		assertEquals(yourBasket.getText(), "1 item");
	}
	
	public void amount()
	{
		assertEquals(checkoutamount.getText(), "₹445.20");
	}
	
	public void drinks()
	{
		adddrinks.click();
	}
	
	public void pepsi() throws InterruptedException
	{
		Thread.sleep(2000);
		addpepsi.click();
	}
	
	public void count() throws InterruptedException
	{
		Thread.sleep(2000);
		assertEquals(yourBasket.getText(), "2 items");
	}
	
	public void after()
	{
		assertEquals(afteramount.getText(), "₹505.06");
		Assert.assertNotSame(afteramount , checkoutamount);
	}
	
	public void remove()
	{
		removepizza.click();
	}
	
	public void cremove() throws InterruptedException
	{
		Thread.sleep(2000);
		assertEquals(removecount.getText(), "1 item");
	}
	
	public void finalcheckout()
	{
		fcheckout.click();
	}
	
	public void minimum()
	{
		assertTrue(minimumorder.isDisplayed());
	}
	
	
}
