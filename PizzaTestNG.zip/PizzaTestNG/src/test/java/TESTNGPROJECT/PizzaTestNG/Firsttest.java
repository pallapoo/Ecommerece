package TESTNGPROJECT.PizzaTestNG;

import org.testng.annotations.Test;

public class Firsttest {

	@Test
	public void pizza()
	{
		
	}
}
