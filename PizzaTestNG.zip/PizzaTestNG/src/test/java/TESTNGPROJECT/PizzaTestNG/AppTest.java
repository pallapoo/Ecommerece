package TESTNGPROJECT.PizzaTestNG;


/**
 * Unit test for simple App.
 */
public class AppTest 
{
   
}
