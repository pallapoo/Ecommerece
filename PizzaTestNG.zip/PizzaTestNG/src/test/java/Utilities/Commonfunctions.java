package Utilities;

import org.openqa.selenium.JavascriptExecutor;

import resources.TestCaseExecution;


public class Commonfunctions extends TestCaseExecution{

		public void scrolldown()
		{
			JavascriptExecutor js=(JavascriptExecutor) (driver);
			js.executeScript("windows.scrollBy(0,250)","");
			
		}
}
