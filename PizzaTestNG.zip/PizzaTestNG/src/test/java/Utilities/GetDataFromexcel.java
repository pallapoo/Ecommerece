package Utilities;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import Constants.Constants;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;


public class GetDataFromexcel {
	
	Constants obj=new Constants();
	
	public static String getUrl() throws IOException
	{
	
	
		FileInputStream fs=new FileInputStream(Constants.TESTDATA);
		XSSFWorkbook workbook=new XSSFWorkbook(fs);
		XSSFSheet sheet=workbook.getSheetAt(0);
		Row row=sheet.getRow(0);
		Cell cell=row.getCell(0);
		
		System.out.println(sheet.getRow(0).getCell(0));
		
		Row row1=sheet.getRow(1);
		Cell cell1=row.getCell(0);
		
		System.out.println(sheet.getRow(1).getCell(0));
		
		XSSFCell value=sheet.getRow(1).getCell(0);
		String Text=value.toString();
		return Text;
	}

}
