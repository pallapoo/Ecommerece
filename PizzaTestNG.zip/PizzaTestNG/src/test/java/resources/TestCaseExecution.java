package resources;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import Extentreportnew.Extentreport;
import Utilities.GetDataFromexcel;


public class TestCaseExecution extends Extentreport{
	
	public static WebDriver driver=new ChromeDriver();
	GetDataFromexcel obj=new GetDataFromexcel();
	
	@BeforeSuite
	public void openBrowser()
	{
		try {
			driver.get(obj.getUrl());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.manage().window().maximize();
	}
	
	@Test
	public void executetest() throws InterruptedException
	{
		
		ConfigReport();
		CreateTest();
		
		WebElement ele =driver.findElement(By.xpath("//*[@id=\"app\"]/div/div[4]/div/div/div/div[2]/form/div/div[1]/input"));
		 ele.sendKeys("neeladriroad");
		 Thread.sleep(2000);
		 ele.sendKeys(Keys.ENTER);
		 Thread.sleep(2000);
		 
		 String currentUrl= "https://www.pizzahut.co.in/order/deals/";//driver.getCurrentUrl();
		
		 
		 System.out.println(currentUrl);
		 Assert.assertTrue(currentUrl.contains("deals"),"URL doesn't contain 'deals'");
		 Thread.sleep(5000);
		 
		 WebElement ele1= driver.findElement(By.xpath("//*[@id=\"app\"]/div/div[1]/div[1]/div[3]/div[1]/div/a[3]/span"));
		 Thread.sleep(2000);
		 ele1.click();
		 Thread.sleep(5000);
		 WebElement ele2= driver.findElement(By.xpath("//*[@id=\"app\"]/div/div[1]/div[1]/div[3]/div[2]/div[2]/span/div/a[1]/div[3]/div/button"));
		 Thread.sleep(2000);
		 ele2.click();
		 driver.findElement(By.xpath("//*[@id=\"app\"]/div/div[1]/div[1]/div[3]/div[1]/div/a[5]")).click();
		 Thread.sleep(3000);
		 driver.findElement(By.xpath("//*[@id=\"app\"]/div/div[1]/div[1]/div[3]/div[2]/div[2]/span/div/a[1]/div[3]/div/button")).click();
		 Thread.sleep(4000);
		 driver.findElement(By.xpath("//*[@id=\"app\"]/div/div[1]/div[1]/div[3]/div[2]/div[2]/span/div/a[2]/div[3]/div/button")).click();
		 Thread.sleep(4000);
		 driver.findElement(By.xpath("//*[@id=\"app\"]/div/div[1]/div[2]/div/div[2]/div[3]/div/div/div/a/span[2]/span")).click();
		 Reporter.log("Navigated to checkout page");
		 
		 Thread.sleep(4000);
		 
		 driver.findElement(By.xpath("//*[@id=\"checkout__name\"]")).sendKeys("Saurabh");
		 Thread.sleep(3000);
		 driver.findElement(By.xpath("//*[@id=\"checkout__phone\"]")).sendKeys("9876543210");
		 Thread.sleep(3000);
		 driver.findElement(By.xpath("//*[@id=\"checkout__email\"]")).sendKeys("example@gmail.com");
		 Thread.sleep(3000);
		 
		 driver.findElement(By.xpath("//*[@id=\"checkout__deliveryAddress.interior\"]")).sendKeys("House number 45");
		 Thread.sleep(3000);
		 
//		 driver.findElement(By.xpath("//*[@id=\"checkout-form\"]/div[4]/div[2]/label[1]/div/div"));
		 WebElement radioElement = driver.findElement(By.xpath("//*[@id=\"checkout-form\"]/div[4]/div[2]/label[1]/div/div"));
		 boolean selectState = radioElement.isSelected();
		 Thread.sleep(3000);
		 
		 driver.findElement(By.xpath("//*[@id=\"checkout-form\"]/div[4]/div[2]/label[3]")).click();
		 
		 Thread.sleep(3000);
		 
		driver.findElement(By.xpath("//*[@id=\"checkout-form\"]/div[3]/button/div/span[2]")).click();
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("/html/body/div[6]/div/div/div/div/div[2]/form/div[2]/input")).sendKeys("12345");
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("/html/body/div[6]/div/div/div/div/div[2]/form/input")).sendKeys("12345");
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("/html/body/div[6]/div/div/div/div/div[2]/form/div[4]/button[1]")).click();
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("/html/body/div[6]/div/div/div/div/div[2]/span")).isDisplayed();
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("/html/body/div[6]/div/div/div/div/div[4]/button[2]")).click();
		
		
		 
	}
	
	@AfterSuite
	
	public void Testcomplition()
	{
		Flushtest();
	}

}
