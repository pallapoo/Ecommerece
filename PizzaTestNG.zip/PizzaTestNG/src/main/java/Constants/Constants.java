package Constants;

public class Constants {

	public static final String TESTDATA="G:\\\\Pooja\\\\Testdata.xlsx";
	public static final String EXTENTREPORTPATH=System.getProperty("user.dir")+"\\test-output\\ExtentReport.html";
}
